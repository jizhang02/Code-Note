import tensorflow as tf
import pickle
from typing import Tuple

from tensorflow.python.keras import Model, Input
from tensorflow.python.keras.layers import (
    Conv2D, MaxPool2D, Conv2DTranspose, Concatenate, Add
)


def load_pretrained_model(
        filepath: str
) -> Tuple[Model, dict, int]:
    """Extract network parameters from model name, construct Keras model, load
    corresponding weights and history"""

    # Residual option
    if '_res_' in filepath:
        residual = True
    elif '_nores_' in filepath:
        residual = False
    else:
        raise ValueError('Invalid model name')

    # Signal domain option
    if '_rf_' in filepath:
        image_shape = (256, 512, 1)  # (H, W, C)
    elif '_bm_' in filepath:
        image_shape = (256, 256, 1)  # (H, W, C)
    else:
        raise ValueError('Invalid model name')

    # Create model w.r.t. to the version (i.e. `small` or `full`)
    if '_small_' in filepath:
        model = create_small_us_unet(
            image_shape=image_shape, residual=residual
        )
    elif '_full_' in filepath:
        model = create_full_us_unet(
            image_shape=image_shape, residual=residual
        )
    else:
        raise ValueError('Invalid model name')

    # Load model weights
    weights_path = filepath + '_weights.h5'
    model.load_weights(filepath=weights_path)

    # Load history
    history_path = filepath + '_history.pickle'
    with open(history_path, 'rb') as f:
        params = pickle.load(f)

    # Unpack history dict and training size (used for plots)
    history = params['training_params']['history']
    train_size = params['training_params']['training_size']

    return model, history, train_size


def create_full_us_unet(
        image_shape: Tuple[int, int, int],  # (H, W, C)
        channel_number: int = 16,
        padding='same',
        residual: bool = True
) -> Model:

    # Network properties
    kernel_shape = (3, 3)
    activation_func = 'relu'
    pool_size = (2, 2)
    channel_factor = 2
    use_bias: bool = True
    caxis = -1  # channel axis

    # Initializers
    kernel_initializer = 'glorot_uniform'
    bias_initializer = 'zeros'

    # Input layer
    inputs = Input(shape=image_shape, dtype=tf.float32)

    # Lists to track some important parts
    skip_maps = list()

    # Initial channel expansion
    fmap = Conv2D(
        filters=channel_number,
        kernel_size=(1, 1),
        # strides=(1, 1),
        padding=padding,
        # data_format=data_format,
        # activation=activation_func,
        activation=None,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(inputs)

    # Downward path (i.e. encoder)#############################################
    _out_ch_nb = channel_number
    # Level 1------------------------------------------------------------------
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)

    # Prepare skip connection
    skip_maps.append(fmap)

    # Downsampling Level 1 -> Level 2------------------------------------------
    fmap = MaxPool2D(
        pool_size=pool_size,
        strides=pool_size,
        padding=padding,
    )(fmap)

    # Convolution + expansion of channel number
    _out_ch_nb *= channel_factor
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        # strides=(1, 1),
        padding=padding,
        # data_format=data_format,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 2------------------------------------------------------------------
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)

    # Prepare skip connection
    skip_maps.append(fmap)

    # Downsampling Level 2 -> Level 3------------------------------------------
    fmap = MaxPool2D(
        pool_size=pool_size,
        strides=pool_size,
        padding=padding,
    )(fmap)

    # Convolution + expansion of channel number
    _out_ch_nb *= channel_factor
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        # strides=(1, 1),
        padding=padding,
        # data_format=data_format,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 3------------------------------------------------------------------
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)

    # Prepare skip connection
    skip_maps.append(fmap)

    # Downsampling Level 3 -> Level 4------------------------------------------
    fmap = MaxPool2D(
        pool_size=pool_size,
        strides=pool_size,
        padding=padding,
    )(fmap)

    # Convolution + expansion of channel number
    _out_ch_nb *= channel_factor
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        # strides=(1, 1),
        padding=padding,
        # data_format=data_format,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 4------------------------------------------------------------------
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)

    # Prepare skip connection
    skip_maps.append(fmap)

    # Downsampling Level 4 -> Level 5------------------------------------------
    fmap = MaxPool2D(
        pool_size=pool_size,
        strides=pool_size,
        padding=padding,
    )(fmap)

    # Convolution + expansion of channel number
    _out_ch_nb *= channel_factor
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        # strides=(1, 1),
        padding=padding,
        # data_format=data_format,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 5 (bottom layer)---------------------------------------------------
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)

    # Upward path##############################################################
    # Upsampling Level 5 -> Level 4--------------------------------------------
    _out_ch_nb //= channel_factor
    # Upsample using transpose convolution
    fmap = Conv2DTranspose(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        strides=pool_size,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 4------------------------------------------------------------------
    # Concatenate skip connection
    fmap = Concatenate(axis=caxis)([fmap, skip_maps[-1]])

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Upsampling Level 4 -> Level 3--------------------------------------------
    _out_ch_nb //= channel_factor
    # Upsample using transpose convolution
    fmap = Conv2DTranspose(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        strides=pool_size,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 3------------------------------------------------------------------
    # Concatenate skip connection
    fmap = Concatenate(axis=caxis)([fmap, skip_maps[-2]])

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Upsampling Level 3 -> Level 2--------------------------------------------
    _out_ch_nb //= channel_factor
    # Upsample using transpose convolution
    fmap = Conv2DTranspose(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        strides=pool_size,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 2------------------------------------------------------------------
    # Concatenate skip connection
    fmap = Concatenate(axis=caxis)([fmap, skip_maps[-3]])

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Upsampling Level 2 -> Level 1--------------------------------------------
    _out_ch_nb //= channel_factor
    # Upsample using transpose convolution
    fmap = Conv2DTranspose(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        strides=pool_size,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 1 (Top Level)------------------------------------------------------
    # Concatenate skip connection
    fmap = Concatenate(axis=caxis)([fmap, skip_maps[-4]])

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Final channel reduction##################################################
    outputs = Conv2D(
        filters=1,
        kernel_size=(1, 1),
        padding=padding,
        activation=None,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Residual skip connection
    if residual:
        outputs = Add()([outputs, inputs])

    # Create Keras sequential model
    model = Model(inputs=inputs, outputs=outputs)

    return model


def create_small_us_unet(
        image_shape: Tuple[int, int, int],  # (H, W, C)
        channel_number: int = 16,
        padding='same',
        residual: bool = True
) -> Model:

    # Network properties
    kernel_shape = (3, 3)
    activation_func = 'relu'
    pool_size = (2, 2)
    channel_factor = 2
    use_bias: bool = True
    caxis = -1  # channel axis

    # Initializers
    kernel_initializer = 'glorot_uniform'
    bias_initializer = 'zeros'

    # Input layer
    inputs = Input(shape=image_shape, dtype=tf.float32)

    # Lists to track some important parts
    skip_maps = list()

    # Initial channel expansion
    fmap = Conv2D(
        filters=channel_number,
        kernel_size=(1, 1),
        # strides=(1, 1),
        padding=padding,
        # data_format=data_format,
        # activation=activation_func,
        activation=None,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(inputs)

    # Downward path (i.e. encoder)#############################################
    _out_ch_nb = channel_number
    # Level 1------------------------------------------------------------------
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)

    # Prepare skip connection
    skip_maps.append(fmap)

    # Downsampling Level 1 -> Level 2------------------------------------------
    fmap = MaxPool2D(
        pool_size=pool_size,
        strides=pool_size,
        padding=padding,
    )(fmap)

    # Convolution + expansion of channel number
    _out_ch_nb *= channel_factor
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        # strides=(1, 1),
        padding=padding,
        # data_format=data_format,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 2------------------------------------------------------------------
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)

    # Prepare skip connection
    skip_maps.append(fmap)

    # Downsampling Level 2 -> Level 3------------------------------------------
    fmap = MaxPool2D(
        pool_size=pool_size,
        strides=pool_size,
        padding=padding,
    )(fmap)

    # Convolution + expansion of channel number
    _out_ch_nb *= channel_factor
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        # strides=(1, 1),
        padding=padding,
        # data_format=data_format,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 3 (bottom Level)---------------------------------------------------
    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer
    )(fmap)

    # Upward path##############################################################
    # Upsampling Level 3 -> Level 2--------------------------------------------
    _out_ch_nb //= channel_factor
    # Upsample using transpose convolution
    fmap = Conv2DTranspose(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        strides=pool_size,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 2------------------------------------------------------------------
    # Concatenate skip connection
    fmap = Concatenate(axis=caxis)([fmap, skip_maps[-1]])

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Upsampling Level 2 -> Level 1--------------------------------------------
    _out_ch_nb //= channel_factor
    # Upsample using transpose convolution
    fmap = Conv2DTranspose(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        strides=pool_size,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Level 1 (Top Level)------------------------------------------------------
    # Concatenate skip connection
    fmap = Concatenate(axis=caxis)([fmap, skip_maps[-2]])

    fmap = Conv2D(
        filters=_out_ch_nb,
        kernel_size=kernel_shape,
        padding=padding,
        activation=activation_func,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Final channel reduction##################################################
    outputs = Conv2D(
        filters=1,
        kernel_size=(1, 1),
        padding=padding,
        activation=None,
        use_bias=use_bias,
        kernel_initializer=kernel_initializer,
        bias_initializer=bias_initializer,
    )(fmap)

    # Residual skip connection
    if residual:
        outputs = Add()([outputs, inputs])

    # Create Keras sequential model
    model = Model(inputs=inputs, outputs=outputs)

    return model