import numpy as np
import h5py
from typing import Tuple, Optional


def load_dataset(
        path: str,
        size: Optional[int] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """Open HDF5 file and load data of size `size`"""

    with h5py.File(path, mode='r') as h5file:
        # Get datasets
        dset_lq = h5file['LQ']
        dset_hq = h5file['HQ']

        # Slice to the given `size`
        dset_len = len(dset_lq)
        if size is not None:
            if not isinstance(size, int):
                raise ValueError('`size` must be an integer')
            if size > dset_len:
                raise ValueError('Maximum `size` is {}'.format(dset_len))
        slc = slice(size)
        data_lq = dset_lq[slc]
        data_hq = dset_hq[slc]

    return data_lq, data_hq


def get_dataset_stats(
        path: str
) -> Tuple[Tuple[float, float], Tuple[float, float]]:
    """Open HDF5 file and load pre-computed mean and standard deviation"""
    with h5py.File(path, mode='r') as h5file:
        # Get datasets
        dset_lq = h5file['LQ']
        dset_hq = h5file['HQ']

        # Extract pre-computed stats
        std_lq, mean_lq = dset_lq.attrs['std'], dset_lq.attrs['mean']
        std_hq, mean_hq = dset_hq.attrs['std'], dset_hq.attrs['mean']

    return (mean_lq, std_lq), (mean_hq, std_hq)


def get_dataset_axes(
        path: str
) -> Tuple[np.ndarray, np.ndarray]:
    """Open HDF5 file and load corresponding image axes"""
    with h5py.File(path, mode='r') as h5file:
        # Extract image axes
        x_axis = h5file['x_axis'][()]
        z_axis = h5file['z_axis'][()]

    return x_axis, z_axis
