import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid
from typing import Optional, Union, List, Tuple, Sequence

Real = Union[int, float]


def plot_image_sequences(
        image_seq: Sequence[np.ndarray],
        name_seq: Optional[Sequence[str]] = None,
        cmap: str = 'gray',
        image_axes: Optional[Tuple[np.ndarray, np.ndarray]] = None,
        data_range: Optional[Tuple[Real, Real]] = None,
        colorbar: bool = False,
):
    # Get number of images to prepare sub-figures
    # images_lq, images_hq = image_sequence  # unpack image pairs
    seq_len = len(image_seq)

    # Name sequence
    name_seq = seq_len * [None] if name_seq is None else name_seq
    if len(name_seq) != seq_len:
        raise ValueError(
            'Name sequence length and image sequence should be identical'
        )

    # Check some shapes
    im_number = len(image_seq[0])
    if im_number > 8:
        raise NotImplementedError('You should consider multiple plots')

    # Compute image limits and scale (meters to millimeters)
    extent = None
    if image_axes is not None:
        x_axis, z_axis = image_axes
        x_min, x_max = x_axis[0], x_axis[-1]
        z_min, z_max = z_axis[0], z_axis[-1]
        extent = [x_min, x_max, z_max, z_min]
        axis_scale = 1e3
        extent = [lim * axis_scale for lim in extent]

    # Data range
    if data_range is None:
        vmin = np.min(image_seq)
        vmax = np.max(image_seq)
    else:
        vmin, vmax = data_range

    # Dict of matplotlib settings
    im_kwargs = {'cmap': cmap, 'extent': extent, 'vmin': vmin, 'vmax': vmax}

    # Create `ImageGrid`
    ig_kwargs = {
        'nrows_ncols': (seq_len, im_number), 'axes_pad': 0.4,
        'share_all': True, 'label_mode': 'L'
    }
    if colorbar:
        cb_kwargs = {
            'cbar_location': 'right', 'cbar_mode': 'edge', 'cbar_size': '10%',
            'cbar_pad': '10%',
        }
        ig_kwargs = {**ig_kwargs, **cb_kwargs}

    # Create matpliotlib figure
    fig = plt.figure(figsize=(18, 9))
    axes = ImageGrid(fig, 111, **ig_kwargs)

    # Draw images in axes
    #   LQ
    for ax_r, images, nm in zip(axes.axes_row, image_seq, name_seq):
        for ax, image in zip(ax_r, images):
            ax.imshow(image.squeeze().T, **im_kwargs)
            ax.set_title(nm)
    #   Labels
    for ax in axes:
        ax.set_xlabel('x [mm]')
        ax.set_ylabel('z [mm]')
    #   Colorbars
    if colorbar:
        # Retrieve a single mappable (all same range)
        mappable = axes[0].images[0]
        for cbar_ax in axes.cbar_axes:
            # Apply mappable to every colorbar
            cb = cbar_ax.colorbar(mappable)
            cb.set_label_text('[dB]')


def plot_histories(
        hists,
        names: Optional[Union[str, List[str]]] = None,
        train_sizes: Optional[Union[int, List[int]]] = None,
):
    if not isinstance(hists, list):
        hists = [hists]
    if names is None:
        names = len(hists) * ['']
    if not isinstance(names, list):
        names = [names]
    xlabel = 'Iteration number'
    if train_sizes is None:
        train_sizes = len(hists) * [1]
        xlabel = 'Epoch number'
    if not isinstance(train_sizes, list):
        train_sizes = [train_sizes]
    if len(hists) is not len(names):
        raise ValueError('Incompatible sequence lengths for names')
    if len(hists) is not len(train_sizes):
        raise ValueError('Incompatible sequence lengths for train_sizes')

    # Create matplotlib figure
    fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(12, 6))
    ax1 = axes

    for hst, nm, ts in zip(hists, names, train_sizes):
        train_str = nm + ' – train' if nm else 'train'
        valid_str = nm + ' – valid' if nm else 'valid'
        xaxis = ts * np.arange(len(hst['loss']))
        l1t = ax1.plot(
            xaxis, hst['loss'], '--', label=train_str + ' loss'
        )
        c1 = l1t[0].get_color()
        l1v = ax1.plot(
            xaxis, hst['val_loss'], color=c1, label=valid_str + ' loss'
        )
        ax1.set_ylabel('Loss')

    # Legend
    ax1.set_xlabel(xlabel=xlabel)
    ax1.grid(True)
    ax1.legend()
