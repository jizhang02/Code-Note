import scipy.signal
import numpy as np
from typing import Tuple, Optional, Union


def normalize_data(
        data: np.ndarray, stats: Tuple[float, float],
        copy: bool = True
) -> np.ndarray:
    """Normalize data by subtracting the mean and dividing by the standard
    deviation.

    Note: to avoid copying the data, the normalization can be carried in-place,
        by setting `copy=False
    """

    # Unpack mean and std
    mean, std = stats

    # Copy data depending in `copy` flag
    out = data.copy() if copy else data

    # Subtract mean and divide by std "in-place"
    out -= mean
    out /= std

    return out


def convert_to_bmode(
        x: np.ndarray,
        norm: Optional[Union[str, int, float]] = None,
) -> np.ndarray:

    # Envelope detection and downsampling
    env = envelope_fir(x=x)[..., ::2]

    # Normalize
    if norm is not None:
        if norm == 'max':
            env /= np.abs(env).max()
        elif (isinstance(norm, int)
              or isinstance(norm, float) or isinstance(norm, np.floating)):
            env /= norm
        else:
            raise NotImplementedError('Unknown normalization method')

    # Log-compression
    bm = compress_log10(x=env, copy=False)
    bm *= 20

    return bm


def envelope_hilbert(x: np.ndarray, axis: int = -1) -> np.ndarray:
    """Envelope detection using Hilbert transform
    """

    # Remove DC offset
    x_nodc, dc = _remove_dc_offset(x=x, axis=axis)

    env = np.abs(scipy.signal.hilbert(x=x_nodc, axis=axis))

    # Restore DC offset
    env += dc

    return env


def envelope_fir(
        x: np.ndarray, filter_size: int = 15
) -> np.ndarray:
    """FIR-filter implementation for envelope detection

    Note: same as Matlab envelope function
    """
    if filter_size % 2 == 0:
        raise ValueError('Must be odd')

    # Remove DC offset
    x_nodc, dc = _remove_dc_offset(x=x, axis=-1)

    # Construct ideal hilbert filter truncated to desired length
    fc = 1
    t = fc / 2 * np.arange((1 - filter_size) / 2, filter_size / 2)
    fir_hilbert = np.sinc(t) * np.exp(1j * np.pi * t)

    # Multiply ideal filter with tapered window
    beta = 8
    fir_hilbert *= scipy.signal.windows.kaiser(filter_size, beta)
    fir_hilbert /= np.sum(fir_hilbert.real)

    # Apply filter and take the magnitude
    env = np.zeros_like(x)
    #   Reshape array to iterate (generalize to any dim)
    x_it = x_nodc.reshape(-1, x.shape[-1])
    env_it = env.reshape(-1, env.shape[-1])
    for s, e in zip(x_it, env_it):
        sig_ana = np.convolve(s, fir_hilbert, 'same')
        e[:] = np.abs(sig_ana)

    # Restore DC offset
    env += dc

    return env


def compress_log10(x: np.ndarray, copy: bool = True) -> np.ndarray:

    # Pointer or copy depending on `copy` flag
    out = x.copy() if copy else x

    # Make sure no negative or zero values
    out[out <= 0] = np.spacing(1, dtype=x.dtype)
    np.log10(x, out=out)

    return out


def _remove_dc_offset(
        x: np.ndarray, axis: int = -1, copy=True
) -> Tuple[np.ndarray, np.ndarray]:

    # Pointer or copy depending on `copy` flag
    out = x.copy() if copy else x

    dc = np.mean(x, axis=axis, keepdims=True)
    out -= dc

    return out, dc
